# Arquivos Necessários para Levar e Funcionar Offline

Guia rápido dos arquivos necessários para copiar em um pendrive ou transferir para qualquer outro computador (sem necessidade de internet e sem Microsoft Office instalado).

Tamanho total do pacote: **menos de 1,1 MB**.

---

## 📦 Arquivos Obrigatórios

Copie todos estes arquivos para dentro da **mesma pasta** no computador de destino:

| Arquivo | Descrição |
| :--- | :--- |
| **`LeitorDePlanilhas.exe`** | O programa executável que você clica com duplo clique para abrir. |
| **`index.html`** | A tela e interface do aplicativo. |
| **`style.css`** | Os estilos visuais, cores e tema escuro/claro. |
| **`app.js`** | Toda a inteligência: leitura das planilhas, cálculo de turnos, filtros e ordenação. |
| **`xlsx.full.min.js`** | Biblioteca offline que lê arquivos Excel (`.xlsx`, `.xls`) sem precisar do Office. |
| **`papaparse.min.js`** | Biblioteca offline que lê arquivos `.csv` mantendo a acentuação correta. |
| **`perfis_pasta.js`** | Arquivo que armazena a lista de JSONs da pasta (se for apagado, o `.exe` recria automaticamente). |

---

## 📄 Seus Arquivos de Configuração (.json)

Coloque na mesma pasta os arquivos `.json` com os nomes de colunas e regras de turnos que você quer que apareçam automaticamente na caixa de seleção:

- **`config_padrao.json`** (Perfil padrão de turnos e nomes amigáveis de colunas)
- Qualquer outro arquivo `.json` que você salvar pelo botão *"Salvar .json"* do aplicativo.

---

## ❌ Arquivos que NÃO precisam ser levados

Estes arquivos eram apenas de teste ou código-fonte inicial e podem ser deixados de fora:

- `Launcher.cs` *(código-fonte em C#, já está compilado dentro do `LeitorDePlanilhas.exe`)*
- `Abrir_Como_Aplicativo.bat`, `Abrir_Leitor.bat`, `iniciar_servidor.bat` *(scripts de teste, o `.exe` substitui todos eles)*
- `Teste1.csv`, `Teste1.xlsx`, `Horário.xlsx` *(eram apenas exemplos para testes)*
- `README.md` *(manual de consulta opcional)*

---

## 🚀 Como Usar no Computador de Destino

1. Conecte o pendrive ou copie a pasta para a Área de Trabalho do computador.
2. Dê um duplo clique direto em **`LeitorDePlanilhas.exe`**.
3. O leitor abrirá instantaneamente em uma janela própria, sem tela preta e sem precisar de permissões de administrador.
4. Carregue suas planilhas `.xlsx` ou `.csv` e selecione o perfil JSON desejado!
