@echo off
title Leitor de Planilhas - Modo Aplicativo
echo Iniciando aplicativo de leitura de planilhas...

set "HTML_PATH=%~dp0index.html"
set "EDGE_PATH=C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"

if exist "%EDGE_PATH%" (
    start "" "%EDGE_PATH%" --app="file:///%HTML_PATH:\=/%"
) else (
    start "" "%HTML_PATH%"
)

exit
