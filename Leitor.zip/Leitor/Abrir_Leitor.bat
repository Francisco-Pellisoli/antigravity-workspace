@echo off
title Leitor e Analisador de Planilhas
echo ========================================================
echo   Iniciando o Leitor e Analisador de Planilhas...
echo   Nao requer instalacao do Microsoft Office!
echo ========================================================
echo.

:: Inicia o navegador padrao apontando para o index.html local
start "" "%~dp0index.html"

exit
