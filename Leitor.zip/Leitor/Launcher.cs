using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace LeitorPlanilhas
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            try
            {
                string baseDir = AppDomain.CurrentDomain.BaseDirectory;
                string htmlPath = Path.Combine(baseDir, "index.html");

                if (!File.Exists(htmlPath))
                {
                    MessageBox.Show(
                        "O arquivo index.html nao foi encontrado na pasta:\n" + baseDir,
                        "Leitor de Planilhas",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                    return;
                }

                // Escaneia todos os arquivos .json presentes na pasta e atualiza perfis_pasta.js
                AtualizarListaPerfisJson(baseDir);

                string fileUri = new Uri(htmlPath).AbsoluteUri;

                // Tenta abrir com Microsoft Edge em modo Janela de Aplicativo Dedicada (--app)
                string[] edgePaths = new string[]
                {
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"Microsoft\Edge\Application\msedge.exe"),
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"Microsoft\Edge\Application\msedge.exe"),
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), @"Microsoft\Edge\Application\msedge.exe")
                };

                string foundEdge = null;
                foreach (string p in edgePaths)
                {
                    if (File.Exists(p))
                    {
                        foundEdge = p;
                        break;
                    }
                }

                if (foundEdge != null)
                {
                    ProcessStartInfo psi = new ProcessStartInfo();
                    psi.FileName = foundEdge;
                    psi.Arguments = "--app=\"" + fileUri + "\"";
                    psi.UseShellExecute = true;
                    Process.Start(psi);
                }
                else
                {
                    // Fallback para navegador padrao do Windows
                    Process.Start(new ProcessStartInfo(fileUri) { UseShellExecute = true });
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Erro ao iniciar o aplicativo:\n" + ex.Message,
                    "Erro",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        static void AtualizarListaPerfisJson(string baseDir)
        {
            try
            {
                string[] jsonFiles = Directory.GetFiles(baseDir, "*.json");
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("// Gerado automaticamente pelo LeitorDePlanilhas.exe");
                sb.AppendLine("window.FOLDER_JSON_FILES = [");

                foreach (string file in jsonFiles)
                {
                    string fileName = Path.GetFileName(file);
                    try
                    {
                        string content = File.ReadAllText(file, Encoding.UTF8);
                        // Valida se o conteudo parece JSON valido
                        string trimmed = content.Trim();
                        if (trimmed.StartsWith("{") && trimmed.EndsWith("}"))
                        {
                            sb.AppendLine("  {");
                            sb.AppendLine("    filename: " + EscapeJsString(fileName) + ",");
                            sb.AppendLine("    data: " + trimmed);
                            sb.AppendLine("  },");
                        }
                    }
                    catch { }
                }

                sb.AppendLine("];");
                File.WriteAllText(Path.Combine(baseDir, "perfis_pasta.js"), sb.ToString(), Encoding.UTF8);
            }
            catch { }
        }

        static string EscapeJsString(string s)
        {
            return "\"" + s.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\r", "").Replace("\n", "") + "\"";
        }
    }
}
