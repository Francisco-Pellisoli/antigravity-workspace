# Leitor & Analisador de Planilhas (Sem Necessidade do Microsoft Office)

Aplicação desenvolvida para leitura, análise, filtragem avançada e cálculo automático de **Turnos** a partir de planilhas Excel (`.xlsx`, `.xls`) e arquivos delimitados (`.csv`), especialmente projetada para computadores que **não possuem o Microsoft Office instalado**.

---

## 🚀 Como Iniciar

Você tem agora um aplicativo executável nativo direto:

1. **Executável Nativo Windows (.exe) - RECOMENDADO**:
   - Dê um duplo clique direto no arquivo [`LeitorDePlanilhas.exe`](file:///c:/Users/Chico/Desktop/Leitor/LeitorDePlanilhas.exe).
   - Abre instantaneamente em uma janela dedicada sem abas, sem tela preta e sem necessidade de scripts.

2. **Modo Navegador Padrão**:
   - Abra o arquivo [`index.html`](file:///c:/Users/Chico/Desktop/Leitor/index.html) no Chrome, Edge ou Firefox.

---

## 🛠️ Principais Recursos

### 1. Nomes Personalizados para as Colunas
- **Renomeie qualquer coluna da planilha**: Diga adeus a cabeçalhos confusos como `Hinicio`, `Hfim`, `cód.`.
- **Editor Visual**: No botão **"Colunas Visíveis & Ordem"**, digite o nome amigável desejado ao lado de cada coluna (ex: `cód.` ➔ `Código do Item`, `Hinicio` ➔ `Hora de Início`).
- **Salvo no Perfil JSON**: Os nomes personalizados ficam salvos no seu perfil e são restaurados sempre que você carregar o perfil.
- **Exportação Limpa**: Ao clicar em **"Exportar Excel"** ou **"Exportar CSV"**, o arquivo gerado já sai com todos os nomes personalizados!

### 2. Leitura Rápida de `.xlsx` e `.csv` sem Office
- **100% Offline e Seguro**: Os dados não saem do seu computador. Não requer internet nem instalação de softwares pesados.
- **Processamento de Grandes Volumes**: Carrega e processa planilhas com muitas colunas e milhares de linhas.
- **Detecção Inteligente**: Interpreta automaticamente datas, frações de tempo do Excel e textos com acentos (`cód.`, `terça-feira`, `sábado`).

### 3. Coluna Calculada de "Turno" via JSON
- A regra de horários contida na sua tabela de referência (`Horário.xlsx`) foi convertida em regras no arquivo [`config_padrao.json`](file:///c:/Users/Chico/Desktop/Leitor/config_padrao.json):
  - **Turno A**: 00:00 às 08:00
  - **Turno B**: 08:00 às 16:00
  - **Turno C**: 16:00 às 24:00
- Ao abrir qualquer planilha com horário (ex: coluna `Hinicio`), o sistema insere automaticamente uma nova coluna com o **Turno** correto e badges coloridas.

### 3. Seleção de Arquivos JSON na Pasta & Procura pelo Explorer
- **Caixa de Seleção com Todos os JSONs da Pasta**:
  - O aplicativo lista automaticamente todos os arquivos `.json` presentes na pasta do programa (ex: `config_padrao.json`, `exemplo_turno_fabrica.json`, etc.).
  - Basta escolher no menu suspenso para trocar instantaneamente de configuração de colunas e turnos!
- **Procurar pelo Explorer**:
  - Para abrir um arquivo `.json` salvo em outra pasta ou pendrive, clique no botão **"📁 Procurar no Explorer..."** ou selecione a opção *"📂 Procurar outro JSON pelo Explorer..."* no menu.
  - A janela do Windows Explorer se abrirá para você escolher o arquivo desejado.
- **Salvar Novos Perfis JSON**:
  - Ao clicar em **"Salvar .json"**, o perfil configurado é salvo em arquivo para você guardar na pasta ou levar para outro computador.

### 4. Filtros Avançados por Coluna (Estilo Excel / Power BI)
- Clique no ícone de funil ao lado de qualquer coluna.
- Pesquise termos específicos dentro do filtro.
- Marque ou desmarque um ou múltiplos itens com contagem de registros.
- Uma barra superior mostra todos os filtros ativos e permite limpá-los com 1 clique.

### 5. Ordenação e Busca Global
- Clique no nome de qualquer coluna para ordenar (Crescente A-Z / 1-9 ou Decrescente Z-A / 9-1).
- Digite na caixa de busca global para localizar qualquer termo na planilha inteira.

### 6. Exportação dos Dados Filtrados
- Exporte para **Excel (.xlsx)** ou **CSV** a qualquer momento, mantendo apenas as colunas visíveis e as linhas filtradas.

---

## 📁 Estrutura dos Arquivos

| Arquivo | Descrição |
| :--- | :--- |
| [`index.html`](file:///c:/Users/Chico/Desktop/Leitor/index.html) | Página principal da aplicação web |
| [`style.css`](file:///c:/Users/Chico/Desktop/Leitor/style.css) | Estilos visuais, modo escuro/claro e componentes |
| [`app.js`](file:///c:/Users/Chico/Desktop/Leitor/app.js) | Lógica de cálculo de turnos, filtros, ordenação e perfis |
| [`config_padrao.json`](file:///c:/Users/Chico/Desktop/Leitor/config_padrao.json) | Configuração inicial em JSON com as regras de horário e colunas |
| [`Abrir_Como_Aplicativo.bat`](file:///c:/Users/Chico/Desktop/Leitor/Abrir_Como_Aplicativo.bat) | Atalho que abre o leitor como janela de aplicativo nativo |
| [`Abrir_Leitor.bat`](file:///c:/Users/Chico/Desktop/Leitor/Abrir_Leitor.bat) | Atalho para abrir no navegador padrão |
| [`iniciar_servidor.bat`](file:///c:/Users/Chico/Desktop/Leitor/iniciar_servidor.bat) | Servidor local opcional em `http://localhost:8080` |
| [`xlsx.full.min.js`](file:///c:/Users/Chico/Desktop/Leitor/xlsx.full.min.js) | Biblioteca de leitura do Excel (offline) |
| [`papaparse.min.js`](file:///c:/Users/Chico/Desktop/Leitor/papaparse.min.js) | Biblioteca de leitura de CSV (offline) |
| [`Teste1.csv`](file:///c:/Users/Chico/Desktop/Leitor/Teste1.csv) / [`Teste1.xlsx`](file:///c:/Users/Chico/Desktop/Leitor/Teste1.xlsx) | Arquivos de exemplo para teste imediato |
