/**
 * Leitor e Analisador de Planilhas Sem Office
 * Suporte a arquivos XLSX, XLS, CSV com grandes volumes de dados.
 * Gerenciamento de Perfis JSON, Cálculo de Turnos e Filtros Excel-Like.
 */

// Estado Global da Aplicação
const State = {
  rawRows: [],          // Linhas originais importadas
  processedRows: [],    // Linhas com coluna calculada 'Turno'
  filteredRows: [],     // Linhas após filtros e busca
  columns: [],          // Lista de todas as colunas disponíveis
  visibleColumns: [],   // Ordem e visibilidade das colunas
  
  // Filtros ativos por coluna: { [columnName]: Set of selected values }
  columnFilters: {},
  globalSearch: '',
  
  // Ordenação
  sortColumn: null,
  sortDirection: 'asc', // 'asc' ou 'desc'
  
  // Paginação
  pageSize: 50,
  currentPage: 1,
  
  // Perfis e Arquivos JSON
  folderProfiles: {}, // Arquivos JSON na pasta do Leitor
  loadedProfiles: {}, // Arquivos JSON carregados via Explorer
  profiles: {},       // Perfis customizados salvos no LocalStorage
  currentProfileKey: 'default',
  currentProfile: null,
  
  // Arquivo carregado
  fileName: '',
  fileSize: ''
};

// Perfil Inicial Padrão
const DEFAULT_PROFILE = {
  profileName: "Turnos de Atendimento (Padrão)",
  description: "Regras de Turno A (00-08h), B (08-16h) e C (16-24h) com nomes personalizados de colunas",
  shiftConfig: {
    enabled: true,
    sourceColumn: "Hinicio",
    targetColumnName: "Turno",
    rules: [
      { shift: "Turno A", startTime: "00:00", endTime: "08:00", color: "#3b82f6" },
      { shift: "Turno B", startTime: "08:00", endTime: "16:00", color: "#10b981" },
      { shift: "Turno C", startTime: "16:00", endTime: "24:00", color: "#f59e0b" }
    ],
    defaultShift: "Sem Turno"
  },
  columns: [
    { name: "cód.", customName: "Código do Item", visible: true },
    { name: "Produto", customName: "Descrição do Produto", visible: true },
    { name: "Inicio", customName: "Data Inicial", visible: true },
    { name: "Hinicio", customName: "Hora Inicial", visible: true },
    { name: "Turno", customName: "Turno de Atendimento", visible: true },
    { name: "Final", customName: "Data Final", visible: true },
    { name: "Hfim", customName: "Hora Final", visible: true }
  ],
  defaultSort: null
};

// ==========================================
// INICIALIZAÇÃO E PERSISTÊNCIA DE PERFIS
// ==========================================

function initProfiles() {
  State.folderProfiles = {};
  State.loadedProfiles = {};

  // 1. Carrega os arquivos JSON detectados na pasta pelo executável
  if (window.FOLDER_JSON_FILES && Array.isArray(window.FOLDER_JSON_FILES)) {
    window.FOLDER_JSON_FILES.forEach(item => {
      if (item && item.filename && item.data) {
        State.folderProfiles[item.filename] = item.data;
      }
    });
  }

  // 2. Se a lista de arquivos da pasta não tiver config_padrao.json, insere o padrão embutido
  if (!State.folderProfiles['config_padrao.json']) {
    State.folderProfiles['config_padrao.json'] = JSON.parse(JSON.stringify(DEFAULT_PROFILE));
  }

  // 3. Carrega perfis salvos do localStorage
  const saved = localStorage.getItem('leitor_planilha_perfis');
  if (saved) {
    try {
      State.profiles = JSON.parse(saved);
    } catch (e) {
      console.error('Erro ao ler perfis salvos', e);
      State.profiles = {};
    }
  } else {
    State.profiles = {};
  }

  // Define perfil inicial ativo: prioriza o config_padrao.json da pasta
  if (State.folderProfiles['config_padrao.json']) {
    State.currentProfileKey = 'folder:config_padrao.json';
    State.currentProfile = JSON.parse(JSON.stringify(State.folderProfiles['config_padrao.json']));
  } else {
    const firstFolderKey = Object.keys(State.folderProfiles)[0];
    if (firstFolderKey) {
      State.currentProfileKey = 'folder:' + firstFolderKey;
      State.currentProfile = JSON.parse(JSON.stringify(State.folderProfiles[firstFolderKey]));
    } else {
      State.currentProfileKey = 'default';
      State.currentProfile = JSON.parse(JSON.stringify(DEFAULT_PROFILE));
    }
  }

  updateProfileDropdown();
}

function saveProfilesToStorage() {
  try {
    localStorage.setItem('leitor_planilha_perfis', JSON.stringify(State.profiles));
  } catch (e) {
    console.warn('Não foi possível salvar perfis no LocalStorage', e);
  }
}

function updateProfileDropdown() {
  const select = document.getElementById('profileSelect');
  if (!select) return;
  
  select.innerHTML = '';

  // 1. Grupo: Arquivos JSON na Pasta do Leitor
  const folderKeys = Object.keys(State.folderProfiles);
  if (folderKeys.length > 0) {
    const optGroupFolder = document.createElement('optgroup');
    optGroupFolder.label = `📂 Arquivos JSON na Pasta (${folderKeys.length})`;
    
    folderKeys.forEach(fn => {
      const p = State.folderProfiles[fn];
      const opt = document.createElement('option');
      opt.value = 'folder:' + fn;
      opt.textContent = `${fn} (${p.profileName || 'Perfil'})`;
      if (opt.value === State.currentProfileKey) opt.selected = true;
      optGroupFolder.appendChild(opt);
    });
    select.appendChild(optGroupFolder);
  }

  // 2. Grupo: Arquivos Carregados pelo Explorer
  const loadedKeys = Object.keys(State.loadedProfiles);
  if (loadedKeys.length > 0) {
    const optGroupLoaded = document.createElement('optgroup');
    optGroupLoaded.label = `📁 Arquivos Carregados pelo Explorer`;
    
    loadedKeys.forEach(fn => {
      const p = State.loadedProfiles[fn];
      const opt = document.createElement('option');
      opt.value = 'loaded:' + fn;
      opt.textContent = `${fn} (${p.profileName || 'Perfil'})`;
      if (opt.value === State.currentProfileKey) opt.selected = true;
      optGroupLoaded.appendChild(opt);
    });
    select.appendChild(optGroupLoaded);
  }

  // 3. Grupo: Perfis Customizados Salvos
  const localKeys = Object.keys(State.profiles);
  if (localKeys.length > 0) {
    const optGroupLocal = document.createElement('optgroup');
    optGroupLocal.label = `💾 Perfis Salvos no Aplicativo`;
    
    localKeys.forEach(k => {
      const p = State.profiles[k];
      const opt = document.createElement('option');
      opt.value = 'local:' + k;
      opt.textContent = p.profileName || k;
      if (opt.value === State.currentProfileKey) opt.selected = true;
      optGroupLocal.appendChild(opt);
    });
    select.appendChild(optGroupLocal);
  }

  // 4. Opção de Procurar no Explorer
  const optGroupAction = document.createElement('optgroup');
  optGroupAction.label = `🔍 Explorador de Arquivos`;
  const optBrowse = document.createElement('option');
  optBrowse.value = '__BROWSE_EXPLORER__';
  optBrowse.textContent = '📂 Procurar outro JSON pelo Explorer...';
  optGroupAction.appendChild(optBrowse);
  select.appendChild(optGroupAction);
}

function switchProfile(profileKey) {
  if (profileKey === '__BROWSE_EXPLORER__') {
    // Abre a janela do explorer e restaura selecao anterior
    document.getElementById('profileFileInput')?.click();
    updateProfileDropdown();
    return;
  }

  let selectedData = null;

  if (profileKey.startsWith('folder:')) {
    const fn = profileKey.replace('folder:', '');
    selectedData = State.folderProfiles[fn];
  } else if (profileKey.startsWith('loaded:')) {
    const fn = profileKey.replace('loaded:', '');
    selectedData = State.loadedProfiles[fn];
  } else if (profileKey.startsWith('local:')) {
    const k = profileKey.replace('local:', '');
    selectedData = State.profiles[k];
  } else if (State.profiles[profileKey]) {
    selectedData = State.profiles[profileKey];
  }

  if (!selectedData) return;

  State.currentProfileKey = profileKey;
  State.currentProfile = JSON.parse(JSON.stringify(selectedData));
  showToast(`Perfil alterado para: "${State.currentProfile.profileName || profileKey}"`);
  
  // Re-processa colunas e turnos se dados estiverem carregados
  if (State.rawRows.length > 0) {
    syncProfileColumnsWithData();
    processDataWithProfile();
  }
}

// ==========================================
// IMPORTAÇÃO E PARSING DE PLANILHAS (XLSX / CSV)
// ==========================================

function handleFileSelect(file) {
  if (!file) return;
  
  const ext = file.name.split('.').pop().toLowerCase();
  State.fileName = file.name;
  State.fileSize = formatFileSize(file.size);
  
  const reader = new FileReader();

  if (ext === 'csv') {
    reader.onload = function(e) {
      parseCSV(e.target.result);
    };
    // Tenta ler com UTF-8
    reader.readAsText(file, 'utf-8');
  } else if (ext === 'xlsx' || ext === 'xls') {
    reader.onload = function(e) {
      parseXLSX(e.target.result);
    };
    reader.readAsArrayBuffer(file);
  } else {
    alert('Formato de arquivo não suportado. Por favor, envie arquivos .xlsx ou .csv');
  }
}

function parseCSV(csvString) {
  Papa.parse(csvString, {
    header: true,
    skipEmptyLines: 'greedy',
    dynamicTyping: false,
    complete: function(results) {
      if (results.errors && results.errors.length > 0) {
        console.warn('PapaParse avisos:', results.errors);
      }
      
      // Sanitizar nomes de colunas
      const fields = results.meta.fields || [];
      const cleanFields = fields.map(f => f.trim()).filter(f => f.length > 0);
      
      const rows = results.data.map(row => {
        const cleanRow = {};
        cleanFields.forEach(col => {
          cleanRow[col] = (row[col] !== undefined && row[col] !== null) ? String(row[col]).trim() : '';
        });
        return cleanRow;
      });

      onDataLoaded(cleanFields, rows);
    }
  });
}

function parseXLSX(arrayBuffer) {
  try {
    const workbook = XLSX.read(arrayBuffer, { 
      type: 'array',
      cellDates: false,
      raw: true
    });
    
    const firstSheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[firstSheetName];
    
    // Converte para JSON com header em formato de linhas brutas
    const jsonData = XLSX.utils.sheet_to_json(worksheet, { 
      raw: true,
      defval: ''
    });

    if (jsonData.length === 0) {
      alert('A planilha selecionada está vazia.');
      return;
    }

    const fields = Object.keys(jsonData[0]);
    
    // Normalizar valores, especialmente horas e datas seriais do Excel
    const rows = jsonData.map(row => {
      const cleanRow = {};
      fields.forEach(col => {
        let val = row[col];
        val = formatExcelValue(col, val);
        cleanRow[col] = val;
      });
      return cleanRow;
    });

    onDataLoaded(fields, rows);
  } catch (err) {
    console.error('Erro ao ler XLSX:', err);
    alert('Erro ao abrir o arquivo Excel. Se o arquivo estiver corrompido, tente salvá-lo novamente.');
  }
}

/**
 * Converte valores brutos do Excel (como frações de hora e seriais de data)
 */
function formatExcelValue(colName, val) {
  if (val === null || val === undefined) return '';
  
  // Se for número puro e o nome da coluna indicar hora (Hinicio, Hfim, Hora, etc.)
  const isTimeCol = /(hora|hinicio|hfim|horario|hr)/i.test(colName);
  const isDateCol = /(data|inicio|fim|final|dt)/i.test(colName) && !isTimeCol;
  
  if (typeof val === 'number') {
    // É uma fração de tempo do Excel (ex: 0.347222 -> 08:20)
    if (isTimeCol || (val >= 0 && val < 1 && val.toString().includes('.'))) {
      return excelTimeToString(val);
    }
    // É uma data serial do Excel (ex: 46275 -> 10/09/2026)
    if (isDateCol && val > 30000 && val < 70000) {
      return excelDateToString(val);
    }
  }
  
  return String(val).trim();
}

function excelTimeToString(serial) {
  const totalSeconds = Math.round(serial * 86400);
  const hours = Math.floor(totalSeconds / 3600) % 24;
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  
  const hh = String(hours).padStart(2, '0');
  const mm = String(minutes).padStart(2, '0');
  if (seconds > 0) {
    const ss = String(seconds).padStart(2, '0');
    return `${hh}:${mm}:${ss}`;
  }
  return `${hh}:${mm}`;
}

function excelDateToString(serial) {
  // Ajuste do bug de ano bissexto do Lotus 1-2-3 (1900)
  const excelEpoch = new Date(1899, 11, 30);
  const date = new Date(excelEpoch.getTime() + serial * 86400000);
  const dd = String(date.getDate()).padStart(2, '0');
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const yyyy = date.getFullYear();
  return `${dd}/${mm}/${yyyy}`;
}

// ==========================================
// PROCESSAMENTO DOS DADOS COM O PERFIL
// ==========================================

function onDataLoaded(columns, rows) {
  State.rawRows = rows;
  State.columns = [...columns];
  
  // Se o perfil atual não possui colunas configuradas para essa planilha,
  // ou se é uma planilha com colunas totalmente diferentes, configura automaticamente
  syncProfileColumnsWithData();
  
  processDataWithProfile();
  
  // Ocultar hero de upload e exibir tabela
  document.getElementById('uploadHero').style.display = 'none';
  document.getElementById('dataSection').style.display = 'flex';
  
  showToast(`Planilha "${State.fileName}" carregada com sucesso! (${rows.length} linhas)`);
}

function syncProfileColumnsWithData() {
  const prof = State.currentProfile;
  const existingColNames = new Set(prof.columns.map(c => c.name));
  
  // Adiciona a coluna de Turno se habilitada
  const shiftColName = prof.shiftConfig?.targetColumnName || 'Turno';
  
  let newCols = [...prof.columns];
  
  // Se estiver vazio, popula com todas as colunas
  if (newCols.length === 0) {
    State.columns.forEach(col => {
      newCols.push({ name: col, customName: '', visible: true });
      // Se essa for a coluna fonte do turno, insere o Turno logo após ela
      if (prof.shiftConfig && prof.shiftConfig.enabled && col === prof.shiftConfig.sourceColumn) {
        newCols.push({ name: shiftColName, customName: 'Turno', visible: true });
      }
    });
    // Se não encontrou a coluna fonte, coloca Turno no final
    if (prof.shiftConfig && prof.shiftConfig.enabled && !newCols.some(c => c.name === shiftColName)) {
      newCols.push({ name: shiftColName, customName: 'Turno', visible: true });
    }
  } else {
    // Adiciona colunas novas que possam estar na planilha mas não no perfil
    State.columns.forEach(col => {
      if (!existingColNames.has(col)) {
        newCols.push({ name: col, customName: '', visible: true });
      }
    });
    if (prof.shiftConfig && prof.shiftConfig.enabled && !newCols.some(c => c.name === shiftColName)) {
      newCols.push({ name: shiftColName, customName: 'Turno', visible: true });
    }
  }
  
  prof.columns = newCols;
}

function processDataWithProfile() {
  const prof = State.currentProfile;
  const shiftCfg = prof.shiftConfig || {};
  const isShiftActive = shiftCfg.enabled && shiftCfg.sourceColumn;
  const shiftColName = shiftCfg.targetColumnName || 'Turno';
  
  // 1. Injeta coluna de Turno em cada linha
  State.processedRows = State.rawRows.map(row => {
    const copy = { ...row };
    if (isShiftActive) {
      const timeVal = row[shiftCfg.sourceColumn] || '';
      copy[shiftColName] = calculateShift(timeVal, shiftCfg.rules, shiftCfg.defaultShift);
    }
    return copy;
  });

  // 2. Determina colunas visíveis
  State.visibleColumns = prof.columns.filter(col => col.visible);

  // 3. Aplica filtros e ordenação
  applyFiltersAndSort();
  
  // 4. Atualiza KPIs e Interface
  updateKPIs();
}

/**
 * Calcula o Turno com base nas regras de horários
 */
function calculateShift(timeStr, rules, defaultShift = 'Sem Turno') {
  if (!timeStr || !rules || rules.length === 0) return defaultShift;
  
  // Tenta extrair hora e minuto
  const minutes = parseTimeToMinutes(timeStr);
  if (minutes === null) return defaultShift;
  
  for (const rule of rules) {
    const startMin = parseTimeToMinutes(rule.startTime);
    const endMin = parseTimeToMinutes(rule.endTime);
    
    if (startMin === null || endMin === null) continue;
    
    // Se o turno cruza a meia noite (ex: 22:00 até 06:00)
    if (endMin <= startMin) {
      if (minutes >= startMin || minutes < endMin) {
        return rule.shift;
      }
    } else {
      if (minutes >= startMin && minutes < endMin) {
        return rule.shift;
      }
    }
  }
  
  return defaultShift;
}

function parseTimeToMinutes(str) {
  if (typeof str === 'number') {
    return Math.round(str * 24 * 60) % 1440;
  }
  if (!str) return null;
  
  const clean = String(str).trim();
  const match = clean.match(/(\d{1,2})[:h](\d{2})/i);
  if (match) {
    const h = parseInt(match[1], 10);
    const m = parseInt(match[2], 10);
    if (h === 24 && m === 0) return 1440;
    return (h * 60) + m;
  }
  
  // Tenta número fracionário em string
  const num = parseFloat(clean);
  if (!isNaN(num) && num >= 0 && num <= 1) {
    return Math.round(num * 24 * 60) % 1440;
  }
  
  return null;
}

// ==========================================
// FILTROS, ORDENAÇÃO E BUSCA
// ==========================================

function applyFiltersAndSort() {
  let rows = [...State.processedRows];
  
  // 1. Busca Global
  if (State.globalSearch && State.globalSearch.trim() !== '') {
    const term = State.globalSearch.toLowerCase().trim();
    rows = rows.filter(row => {
      return Object.values(row).some(val => 
        String(val).toLowerCase().includes(term)
      );
    });
  }
  
  // 2. Filtros por Coluna
  const activeColFilterKeys = Object.keys(State.columnFilters);
  if (activeColFilterKeys.length > 0) {
    rows = rows.filter(row => {
      for (const col of activeColFilterKeys) {
        const allowedSet = State.columnFilters[col];
        if (allowedSet && allowedSet.size > 0) {
          const val = String(row[col] ?? '');
          if (!allowedSet.has(val)) {
            return false;
          }
        }
      }
      return true;
    });
  }
  
  // 3. Ordenação
  if (State.sortColumn) {
    const col = State.sortColumn;
    const dir = State.sortDirection === 'asc' ? 1 : -1;
    
    rows.sort((a, b) => {
      const valA = a[col] ?? '';
      const valB = b[col] ?? '';
      
      // Teste numérico
      const numA = Number(valA);
      const numB = Number(valB);
      if (!isNaN(numA) && !isNaN(numB) && valA !== '' && valB !== '') {
        return (numA - numB) * dir;
      }
      
      // Teste de data pt-BR (DD/MM/YYYY)
      const dateRegex = /^\d{2}\/\d{2}\/\d{4}$/;
      if (dateRegex.test(valA) && dateRegex.test(valB)) {
        const parseD = s => {
          const parts = s.split('/');
          return new Date(parts[2], parts[1] - 1, parts[0]).getTime();
        };
        return (parseD(valA) - parseD(valB)) * dir;
      }
      
      return String(valA).localeCompare(String(valB), 'pt-BR', { numeric: true, sensitivity: 'base' }) * dir;
    });
  }
  
  State.filteredRows = rows;
  State.currentPage = 1;
  
  renderTable();
  renderPagination();
  renderActiveFiltersSummary();
  updateKPIs();
}

function handleSort(colName) {
  if (State.sortColumn === colName) {
    if (State.sortDirection === 'asc') {
      State.sortDirection = 'desc';
    } else {
      State.sortColumn = null;
      State.sortDirection = 'asc';
    }
  } else {
    State.sortColumn = colName;
    State.sortDirection = 'asc';
  }
  applyFiltersAndSort();
}

// ==========================================
// RENDERIZAÇÃO DA TABELA E COMPONENTES
// ==========================================

function renderTable() {
  const thead = document.getElementById('tableThead');
  const tbody = document.getElementById('tableTbody');
  if (!thead || !tbody) return;
  
  // Cabeçalho
  thead.innerHTML = '';
  const trHead = document.createElement('tr');
  
  State.visibleColumns.forEach(colObj => {
    const colName = colObj.name;
    const displayName = (colObj.customName && colObj.customName.trim() !== '') ? colObj.customName.trim() : colName;
    const hasCustom = displayName !== colName;
    const th = document.createElement('th');
    
    const isSorted = State.sortColumn === colName;
    const sortIcon = isSorted ? (State.sortDirection === 'asc' ? '▲' : '▼') : '↕';
    const isFiltered = State.columnFilters[colName] && State.columnFilters[colName].size > 0;
    
    th.innerHTML = `
      <div class="th-content">
        <div class="th-title-group" title="${hasCustom ? 'Coluna original na planilha: ' + escapeHTML(colName) + ' (Clique para ordenar)' : 'Clique para ordenar'}">
          <div style="display: flex; flex-direction: column; align-items: flex-start; line-height: 1.2;">
            <span class="th-title">${escapeHTML(displayName)}</span>
            ${hasCustom ? `<span class="th-orig-name">(${escapeHTML(colName)})</span>` : ''}
          </div>
          <span class="sort-indicator ${isSorted ? 'sort-active' : ''}">${sortIcon}</span>
        </div>
        <div class="th-actions">
          <button class="btn-filter-icon ${isFiltered ? 'filter-active' : ''}" title="Filtrar coluna" data-col="${escapeHTML(colName)}">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"></polygon>
            </svg>
          </button>
        </div>
      </div>
    `;
    
    // Evento de ordenação
    th.querySelector('.th-title-group').addEventListener('click', () => {
      handleSort(colName);
    });
    
    // Evento de filtro
    th.querySelector('.btn-filter-icon').addEventListener('click', (e) => {
      e.stopPropagation();
      openColumnFilterPopover(colName, e.currentTarget);
    });
    
    trHead.appendChild(th);
  });
  thead.appendChild(trHead);
  
  // Linhas com Paginação
  tbody.innerHTML = '';
  const rows = State.filteredRows;
  
  if (rows.length === 0) {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td colspan="${State.visibleColumns.length || 1}" class="empty-state">
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <circle cx="11" cy="11" r="8"></circle>
          <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
        </svg>
        <p>Nenhum registro encontrado para os filtros selecionados.</p>
      </td>
    `;
    tbody.appendChild(tr);
    return;
  }
  
  // Paginação
  let startIndex = 0;
  let endIndex = rows.length;
  if (State.pageSize !== 'all') {
    const ps = parseInt(State.pageSize, 10);
    startIndex = (State.currentPage - 1) * ps;
    endIndex = Math.min(startIndex + ps, rows.length);
  }
  
  const pageRows = rows.slice(startIndex, endIndex);
  const shiftColName = State.currentProfile?.shiftConfig?.targetColumnName || 'Turno';
  const shiftRules = State.currentProfile?.shiftConfig?.rules || [];
  
  pageRows.forEach(row => {
    const tr = document.createElement('tr');
    
    State.visibleColumns.forEach(colObj => {
      const colName = colObj.name;
      const td = document.createElement('td');
      const val = row[colName] ?? '';
      
      // Se for a coluna de Turno, aplica badge colorida estilosa!
      if (colName === shiftColName && val !== '') {
        const rule = shiftRules.find(r => r.shift === val);
        const color = rule ? rule.color : '#64748b';
        td.innerHTML = `
          <span class="badge-shift" style="background: ${color}20; color: ${color}; border: 1px solid ${color}40;">
            <span class="badge-shift-dot" style="background: ${color};"></span>
            ${escapeHTML(val)}
          </span>
        `;
      } else {
        td.textContent = val;
      }
      
      tr.appendChild(td);
    });
    
    tbody.appendChild(tr);
  });
}

function renderPagination() {
  const info = document.getElementById('paginationInfo');
  const controls = document.getElementById('paginationControls');
  if (!info || !controls) return;
  
  const total = State.filteredRows.length;
  if (total === 0) {
    info.textContent = '0 registros';
    controls.innerHTML = '';
    return;
  }
  
  if (State.pageSize === 'all') {
    info.textContent = `Mostrando todos os ${total} registros`;
    controls.innerHTML = '';
    return;
  }
  
  const ps = parseInt(State.pageSize, 10);
  const totalPages = Math.ceil(total / ps);
  const start = ((State.currentPage - 1) * ps) + 1;
  const end = Math.min(start + ps - 1, total);
  
  info.textContent = `Mostrando ${start} a ${end} de ${total} registros`;
  
  controls.innerHTML = `
    <button class="btn btn-sm btn-outline" id="btnPageFirst" ${State.currentPage === 1 ? 'disabled' : ''}>«</button>
    <button class="btn btn-sm btn-outline" id="btnPagePrev" ${State.currentPage === 1 ? 'disabled' : ''}>‹</button>
    <span style="font-weight: 600; padding: 0 0.5rem;">Página ${State.currentPage} de ${totalPages}</span>
    <button class="btn btn-sm btn-outline" id="btnPageNext" ${State.currentPage === totalPages ? 'disabled' : ''}>›</button>
    <button class="btn btn-sm btn-outline" id="btnPageLast" ${State.currentPage === totalPages ? 'disabled' : ''}>»</button>
  `;
  
  document.getElementById('btnPageFirst')?.addEventListener('click', () => { State.currentPage = 1; renderTable(); renderPagination(); });
  document.getElementById('btnPagePrev')?.addEventListener('click', () => { State.currentPage--; renderTable(); renderPagination(); });
  document.getElementById('btnPageNext')?.addEventListener('click', () => { State.currentPage++; renderTable(); renderPagination(); });
  document.getElementById('btnPageLast')?.addEventListener('click', () => { State.currentPage = totalPages; renderTable(); renderPagination(); });
}

function renderActiveFiltersSummary() {
  const container = document.getElementById('activeFiltersBar');
  const countSpan = document.getElementById('activeFiltersCount');
  const tagsContainer = document.getElementById('activeFiltersTags');
  if (!container || !tagsContainer) return;
  
  const filterCols = Object.keys(State.columnFilters).filter(col => State.columnFilters[col] && State.columnFilters[col].size > 0);
  
  if (filterCols.length === 0 && !State.globalSearch) {
    container.style.display = 'none';
    return;
  }
  
  container.style.display = 'flex';
  tagsContainer.innerHTML = '';
  
  if (countSpan) countSpan.textContent = filterCols.length + (State.globalSearch ? 1 : 0);
  
  if (State.globalSearch) {
    const tag = document.createElement('div');
    tag.className = 'filter-tag';
    tag.innerHTML = `Busca: "${escapeHTML(State.globalSearch)}" <span class="filter-tag-remove" title="Remover">&times;</span>`;
    tag.querySelector('.filter-tag-remove').addEventListener('click', () => {
      State.globalSearch = '';
      const input = document.getElementById('globalSearchInput');
      if (input) input.value = '';
      applyFiltersAndSort();
    });
    tagsContainer.appendChild(tag);
  }
  
  filterCols.forEach(col => {
    const count = State.columnFilters[col].size;
    const tag = document.createElement('div');
    tag.className = 'filter-tag';
    tag.innerHTML = `${escapeHTML(col)}: (${count} selecionado${count > 1 ? 's' : ''}) <span class="filter-tag-remove" title="Remover">&times;</span>`;
    tag.querySelector('.filter-tag-remove').addEventListener('click', () => {
      delete State.columnFilters[col];
      applyFiltersAndSort();
    });
    tagsContainer.appendChild(tag);
  });
}

function updateKPIs() {
  const total = State.processedRows.length;
  const filtered = State.filteredRows.length;
  
  const totalEl = document.getElementById('kpiTotalRows');
  const filteredEl = document.getElementById('kpiFilteredRows');
  const shiftDistributionEl = document.getElementById('kpiShiftDistribution');
  const fileInfoEl = document.getElementById('kpiFileInfo');
  
  if (totalEl) totalEl.textContent = total.toLocaleString('pt-BR');
  if (filteredEl) filteredEl.textContent = filtered.toLocaleString('pt-BR');
  if (fileInfoEl) fileInfoEl.textContent = State.fileName ? `${State.fileName} (${State.fileSize})` : 'Nenhum';
  
  // Distribuição de Turnos
  if (shiftDistributionEl) {
    const shiftColName = State.currentProfile?.shiftConfig?.targetColumnName || 'Turno';
    const counts = {};
    State.filteredRows.forEach(r => {
      const s = r[shiftColName] || 'Outro';
      counts[s] = (counts[s] || 0) + 1;
    });
    
    shiftDistributionEl.innerHTML = '';
    const rules = State.currentProfile?.shiftConfig?.rules || [];
    
    Object.keys(counts).forEach(shiftName => {
      const c = counts[shiftName];
      const pct = total > 0 ? Math.round((c / filtered) * 100) : 0;
      const rule = rules.find(r => r.shift === shiftName);
      const color = rule ? rule.color : '#64748b';
      
      const badge = document.createElement('span');
      badge.className = 'badge';
      badge.style.border = `1px solid ${color}40`;
      badge.style.background = `${color}15`;
      badge.style.color = color;
      badge.textContent = `${shiftName}: ${c} (${pct}%)`;
      shiftDistributionEl.appendChild(badge);
    });
  }
}

// ==========================================
// POPOVER DE FILTRO POR COLUNA (EXCEL-LIKE)
// ==========================================

let activeFilterPopover = null;

function openColumnFilterPopover(colName, triggerBtn) {
  closeFilterPopover();
  
  // Obter valores únicos presentes na coluna (de toda a base processada ou da base filtrada sem o filtro da própria coluna)
  const valCountMap = new Map();
  State.processedRows.forEach(row => {
    // Para UX idêntica ao Excel: considera os outros filtros ativos
    let allowed = true;
    for (const otherCol of Object.keys(State.columnFilters)) {
      if (otherCol !== colName) {
        const allowedSet = State.columnFilters[otherCol];
        if (allowedSet && allowedSet.size > 0 && !allowedSet.has(String(row[otherCol] ?? ''))) {
          allowed = false;
          break;
        }
      }
    }
    if (allowed) {
      const val = String(row[colName] ?? '');
      valCountMap.set(val, (valCountMap.get(val) || 0) + 1);
    }
  });
  
  // Ordena valores únicos
  const sortedValues = Array.from(valCountMap.keys()).sort((a, b) => {
    const numA = Number(a);
    const numB = Number(b);
    if (!isNaN(numA) && !isNaN(numB) && a !== '' && b !== '') return numA - numB;
    return a.localeCompare(b, 'pt-BR', { numeric: true });
  });
  
  // Conjunto de valores selecionados atualmente
  const currentSelected = State.columnFilters[colName] 
    ? new Set(State.columnFilters[colName]) 
    : new Set(sortedValues); // Se nenhum filtro ativo, todos estão marcados
    
  const popover = document.createElement('div');
  popover.className = 'filter-popover';
  popover.id = 'activeColumnFilterPopover';
  
  popover.innerHTML = `
    <div class="filter-popover-header">
      <input type="text" class="filter-search-input" placeholder="Pesquisar valores..." id="popoverSearchInput">
      <div class="filter-popover-actions">
        <button id="btnSelectAllValues">Marcar Todos</button>
        <button id="btnUnselectAllValues">Desmarcar Todos</button>
      </div>
    </div>
    <div class="filter-items-list" id="popoverItemsList">
      ${sortedValues.map(val => `
        <label class="filter-item-label">
          <span class="filter-item-text">
            <input type="checkbox" value="${escapeHTML(val)}" ${currentSelected.has(val) ? 'checked' : ''} class="filter-val-checkbox">
            <span>${escapeHTML(val === '' ? '(Vazio)' : val)}</span>
          </span>
          <span class="filter-item-count">(${valCountMap.get(val)})</span>
        </label>
      `).join('')}
    </div>
    <div class="filter-popover-footer">
      <button class="btn btn-sm btn-outline" id="btnClearColumnFilter">Limpar</button>
      <button class="btn btn-sm btn-primary" id="btnApplyColumnFilter">Aplicar</button>
    </div>
  `;
  
  // Posicionamento relativo ao botão e verificação de borda da tela
  const th = triggerBtn.closest('th');
  th.style.position = 'relative';
  th.appendChild(popover);
  activeFilterPopover = popover;

  const rect = th.getBoundingClientRect();
  if (rect.left < 270) {
    popover.style.right = 'auto';
    popover.style.left = '0';
  } else {
    popover.style.right = '0';
    popover.style.left = 'auto';
  }
  
  // Foco na pesquisa
  const searchInput = popover.querySelector('#popoverSearchInput');
  setTimeout(() => searchInput.focus(), 50);
  
  // Filtro de pesquisa na lista
  searchInput.addEventListener('input', (e) => {
    const q = e.target.value.toLowerCase();
    popover.querySelectorAll('.filter-item-label').forEach(lbl => {
      const text = lbl.querySelector('.filter-item-text span').textContent.toLowerCase();
      lbl.style.display = text.includes(q) ? 'flex' : 'none';
    });
  });
  
  // Marcar / Desmarcar todos
  popover.querySelector('#btnSelectAllValues').addEventListener('click', () => {
    popover.querySelectorAll('.filter-val-checkbox').forEach(cb => cb.checked = true);
  });
  popover.querySelector('#btnUnselectAllValues').addEventListener('click', () => {
    popover.querySelectorAll('.filter-val-checkbox').forEach(cb => cb.checked = false);
  });
  
  // Limpar filtro da coluna
  popover.querySelector('#btnClearColumnFilter').addEventListener('click', () => {
    delete State.columnFilters[colName];
    closeFilterPopover();
    applyFiltersAndSort();
  });
  
  // Aplicar filtro
  popover.querySelector('#btnApplyColumnFilter').addEventListener('click', () => {
    const checkedValues = [];
    popover.querySelectorAll('.filter-val-checkbox:checked').forEach(cb => {
      checkedValues.push(cb.value);
    });
    
    // Se selecionou todos os valores, remove o filtro para desempenho
    if (checkedValues.length === sortedValues.length) {
      delete State.columnFilters[colName];
    } else {
      State.columnFilters[colName] = new Set(checkedValues);
    }
    
    closeFilterPopover();
    applyFiltersAndSort();
  });
}

function closeFilterPopover() {
  if (activeFilterPopover && activeFilterPopover.parentNode) {
    activeFilterPopover.parentNode.removeChild(activeFilterPopover);
  }
  activeFilterPopover = null;
}

// Fecha popover ao clicar fora
document.addEventListener('click', (e) => {
  if (activeFilterPopover && !activeFilterPopover.contains(e.target)) {
    closeFilterPopover();
  }
});

// ==========================================
// MODAL DE CONFIGURAÇÃO DE COLUNAS
// ==========================================

let columnSearchTerm = '';

function openColumnsModal() {
  const modal = document.getElementById('modalColumns');
  const list = document.getElementById('columnsConfigList');
  if (!modal || !list) return;
  
  renderColumnsModalList();
  
  // Input de pesquisa de colunas
  const searchInput = document.getElementById('colSearchModalInput');
  if (searchInput) {
    searchInput.value = columnSearchTerm;
    searchInput.oninput = (e) => {
      columnSearchTerm = e.target.value.toLowerCase().trim();
      renderColumnsModalList();
    };
  }

  modal.classList.add('active');
}

function renderColumnsModalList() {
  const list = document.getElementById('columnsConfigList');
  const badge = document.getElementById('colCountBadge');
  if (!list) return;
  
  list.innerHTML = '';
  const cols = State.currentProfile.columns;
  const visibleCount = cols.filter(c => c.visible).length;
  
  if (badge) {
    badge.textContent = `${visibleCount} de ${cols.length} visíveis`;
  }
  
  cols.forEach((col, idx) => {
    // Se houver busca, filtra visualmente
    if (columnSearchTerm && !col.name.toLowerCase().includes(columnSearchTerm)) {
      return;
    }
    
    const row = document.createElement('div');
    row.className = 'column-config-row';
    row.dataset.colName = col.name;
    row.dataset.idx = idx;
    
    const customVal = col.customName || '';
    
    row.innerHTML = `
      <div class="column-config-info">
        <input type="checkbox" id="col_chk_${idx}" ${col.visible ? 'checked' : ''} class="col-visibility-chk">
        <span style="color: var(--text-muted); font-size: 0.75rem; min-width: 24px;">#${idx + 1}</span>
        <div class="col-name-container">
          <span class="col-orig-label" title="Coluna original: ${escapeHTML(col.name)}">${escapeHTML(col.name)}</span>
          <input type="text" class="col-custom-input" placeholder="Nome personalizado de exibição..." value="${escapeHTML(customVal)}" title="Digite o nome que será mostrado nesta coluna">
        </div>
      </div>
      <div class="column-config-actions">
        <button class="btn btn-sm btn-outline btn-col-up" title="Mover para cima" ${idx === 0 ? 'disabled' : ''}>↑</button>
        <button class="btn btn-sm btn-outline btn-col-down" title="Mover para baixo" ${idx === cols.length - 1 ? 'disabled' : ''}>↓</button>
      </div>
    `;
    
    row.querySelector('.col-visibility-chk').addEventListener('change', (e) => {
      col.visible = e.target.checked;
      const newVisibleCount = cols.filter(c => c.visible).length;
      if (badge) badge.textContent = `${newVisibleCount} de ${cols.length} visíveis`;
    });

    row.querySelector('.col-custom-input').addEventListener('input', (e) => {
      col.customName = e.target.value.trim();
    });
    
    row.querySelector('.btn-col-up').addEventListener('click', () => {
      if (idx > 0) {
        const temp = cols[idx];
        cols[idx] = cols[idx - 1];
        cols[idx - 1] = temp;
        renderColumnsModalList();
      }
    });
    
    row.querySelector('.btn-col-down').addEventListener('click', () => {
      if (idx < cols.length - 1) {
        const temp = cols[idx];
        cols[idx] = cols[idx + 1];
        cols[idx + 1] = temp;
        renderColumnsModalList();
      }
    });
    
    list.appendChild(row);
  });
}

function closeColumnsModal() {
  document.getElementById('modalColumns')?.classList.remove('active');
  columnSearchTerm = '';
  const searchInput = document.getElementById('colSearchModalInput');
  if (searchInput) searchInput.value = '';
}

// ==========================================
// MODAL DE CONFIGURAÇÃO DE TURNOS E PERFIL
// ==========================================

function openShiftModal() {
  const modal = document.getElementById('modalShift');
  if (!modal) return;
  
  const prof = State.currentProfile;
  const cfg = prof.shiftConfig || { rules: [] };
  
  // Preencher campos
  document.getElementById('profileNameInput').value = prof.profileName || '';
  document.getElementById('profileDescInput').value = prof.description || '';
  document.getElementById('shiftEnableCheck').checked = cfg.enabled !== false;
  document.getElementById('shiftTargetColInput').value = cfg.targetColumnName || 'Turno';
  
  // Opções de colunas para fonte do horário
  const select = document.getElementById('shiftSourceColSelect');
  select.innerHTML = '<option value="">-- Selecione a Coluna de Horário --</option>';
  State.columns.forEach(col => {
    const opt = document.createElement('option');
    opt.value = col;
    opt.textContent = col;
    if (col === cfg.sourceColumn) opt.selected = true;
    select.appendChild(opt);
  });
  
  renderShiftRulesEditor(cfg.rules);
  modal.classList.add('active');
}

function renderShiftRulesEditor(rules) {
  const tbody = document.getElementById('shiftRulesTbody');
  if (!tbody) return;
  tbody.innerHTML = '';
  
  rules.forEach((rule, idx) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><input type="text" value="${escapeHTML(rule.shift)}" class="shift-input rule-shift-name" placeholder="Ex: Turno A"></td>
      <td><input type="time" value="${rule.startTime}" class="shift-input rule-start-time"></td>
      <td><input type="time" value="${rule.endTime}" class="shift-input rule-end-time"></td>
      <td><input type="color" value="${rule.color || '#3b82f6'}" class="rule-color" style="height: 32px; width: 45px; border: none; cursor: pointer;"></td>
      <td style="text-align: center;">
        <button class="btn btn-sm btn-outline btn-remove-rule" title="Excluir regra" style="color: var(--danger);">&times;</button>
      </td>
    `;
    
    tr.querySelector('.btn-remove-rule').addEventListener('click', () => {
      rules.splice(idx, 1);
      renderShiftRulesEditor(rules);
    });
    
    tbody.appendChild(tr);
  });
}

function saveShiftModalChanges() {
  const prof = State.currentProfile;
  prof.profileName = document.getElementById('profileNameInput').value.trim() || 'Meu Perfil';
  prof.description = document.getElementById('profileDescInput').value.trim();
  
  const rules = [];
  document.querySelectorAll('#shiftRulesTbody tr').forEach(tr => {
    const shift = tr.querySelector('.rule-shift-name').value.trim();
    const startTime = tr.querySelector('.rule-start-time').value;
    const endTime = tr.querySelector('.rule-end-time').value;
    const color = tr.querySelector('.rule-color').value;
    if (shift && startTime && endTime) {
      rules.push({ shift, startTime, endTime, color });
    }
  });
  
  prof.shiftConfig = {
    enabled: document.getElementById('shiftEnableCheck').checked,
    sourceColumn: document.getElementById('shiftSourceColSelect').value,
    targetColumnName: document.getElementById('shiftTargetColInput').value.trim() || 'Turno',
    rules: rules,
    defaultShift: 'Sem Turno'
  };
  
  // Salva no perfil global
  State.profiles[State.currentProfileKey] = JSON.parse(JSON.stringify(prof));
  saveProfilesToStorage();
  updateProfileDropdown();
  
  // Fecha modal e reprocessa
  document.getElementById('modalShift').classList.remove('active');
  syncProfileColumnsWithData();
  processDataWithProfile();
  showToast('Configurações de Turno e Perfil atualizadas!');
}

// ==========================================
// EXPORTAÇÃO E IMPORTAÇÃO DE PERFIS JSON
// ==========================================

function exportCurrentProfileJSON() {
  const jsonStr = JSON.stringify(State.currentProfile, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const fileName = (State.currentProfile.profileName || 'perfil_config').toLowerCase().replace(/\s+/g, '_') + '.json';
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showToast(`Perfil exportado com sucesso: ${fileName}`);
}

function importProfileJSON(file) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function(e) {
    try {
      const data = JSON.parse(e.target.result);
      if (!data.profileName && !data.columns) {
        throw new Error('Arquivo JSON não possui formato de perfil válido.');
      }
      if (!data.profileName) {
        data.profileName = file.name.replace(/\.json$/i, '');
      }
      const fn = file.name;
      State.loadedProfiles[fn] = data;
      State.currentProfileKey = 'loaded:' + fn;
      State.currentProfile = JSON.parse(JSON.stringify(data));
      updateProfileDropdown();
      if (State.rawRows.length > 0) {
        syncProfileColumnsWithData();
        processDataWithProfile();
      }
      showToast(`Arquivo JSON "${fn}" carregado com sucesso pelo Explorer!`);
    } catch (err) {
      alert('Erro ao carregar arquivo de perfil JSON: ' + err.message);
    }
  };
  reader.readAsText(file, 'utf-8');
}

// ==========================================
// EXPORTAÇÃO DE DADOS (EXCEL / CSV)
// ==========================================

function exportDataToExcel() {
  if (State.filteredRows.length === 0) {
    alert('Não há dados para exportar.');
    return;
  }
  
  // Filtra apenas colunas visíveis com seus nomes personalizados
  const exportRows = State.filteredRows.map(row => {
    const r = {};
    State.visibleColumns.forEach(colObj => {
      const headerName = (colObj.customName && colObj.customName.trim() !== '') ? colObj.customName.trim() : colObj.name;
      r[headerName] = row[colObj.name] ?? '';
    });
    return r;
  });
  
  const worksheet = XLSX.utils.json_to_sheet(exportRows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Dados");
  
  const baseName = State.fileName ? State.fileName.replace(/\.[^/.]+$/, "") : "planilha";
  XLSX.writeFile(workbook, `${baseName}_filtrado.xlsx`);
  showToast('Planilha exportada para Excel com nomes personalizados!');
}

function exportDataToCSV() {
  if (State.filteredRows.length === 0) {
    alert('Não há dados para exportar.');
    return;
  }
  
  const exportRows = State.filteredRows.map(row => {
    const r = {};
    State.visibleColumns.forEach(colObj => {
      const headerName = (colObj.customName && colObj.customName.trim() !== '') ? colObj.customName.trim() : colObj.name;
      r[headerName] = row[colObj.name] ?? '';
    });
    return r;
  });
  
  const csv = Papa.unparse(exportRows, { delimiter: ';' });
  // Adiciona BOM para UTF-8 garantindo acentuação no Excel
  const blob = new Blob(["\uFEFF" + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const baseName = State.fileName ? State.fileName.replace(/\.[^/.]+$/, "") : "planilha";
  a.download = `${baseName}_filtrado.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showToast('Arquivo CSV exportado com nomes personalizados!');
}

// ==========================================
// UTILITÁRIOS E HELPERS
// ==========================================

function formatFileSize(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

function escapeHTML(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function showToast(message) {
  const oldToast = document.querySelector('.toast');
  if (oldToast) oldToast.remove();
  
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2">
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
      <polyline points="22 4 12 14.01 9 11.01"></polyline>
    </svg>
    <span>${escapeHTML(message)}</span>
  `;
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// ==========================================
// BIND DE EVENTOS DA INTERFACE
// ==========================================

document.addEventListener('DOMContentLoaded', () => {
  initProfiles();
  
  // Upload Drop Zone
  const uploadZone = document.getElementById('uploadHero');
  const fileInput = document.getElementById('fileInput');
  
  if (uploadZone && fileInput) {
    uploadZone.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', (e) => {
      if (e.target.files.length > 0) handleFileSelect(e.target.files[0]);
    });
    
    uploadZone.addEventListener('dragover', (e) => {
      e.preventDefault();
      uploadZone.classList.add('drag-over');
    });
    
    uploadZone.addEventListener('dragleave', () => {
      uploadZone.classList.remove('drag-over');
    });
    
    uploadZone.addEventListener('drop', (e) => {
      e.preventDefault();
      uploadZone.classList.remove('drag-over');
      if (e.dataTransfer.files.length > 0) {
        handleFileSelect(e.dataTransfer.files[0]);
      }
    });
  }
  
  // Botão Trocar Planilha / Nova Planilha
  document.getElementById('btnNewFile')?.addEventListener('click', () => {
    fileInput.click();
  });
  
  // Dropdown de Perfis
  document.getElementById('profileSelect')?.addEventListener('change', (e) => {
    switchProfile(e.target.value);
  });
  
  // Botão Configurar Turnos e Perfil
  document.getElementById('btnConfigShift')?.addEventListener('click', openShiftModal);
  document.getElementById('btnCloseShiftModal')?.addEventListener('click', () => {
    document.getElementById('modalShift').classList.remove('active');
  });
  document.getElementById('btnSaveShiftConfig')?.addEventListener('click', saveShiftModalChanges);
  
  // Adicionar Nova Regra de Turno
  document.getElementById('btnAddShiftRule')?.addEventListener('click', () => {
    const rules = State.currentProfile.shiftConfig.rules || [];
    rules.push({ shift: `Turno ${String.fromCharCode(65 + rules.length)}`, startTime: "08:00", endTime: "16:00", color: "#6366f1" });
    renderShiftRulesEditor(rules);
  });
  
  // Botão Gerenciar Colunas
  document.getElementById('btnConfigColumns')?.addEventListener('click', openColumnsModal);
  document.getElementById('btnCloseColumnsModal')?.addEventListener('click', closeColumnsModal);
  document.getElementById('btnSaveColumnsConfig')?.addEventListener('click', () => {
    closeColumnsModal();
    processDataWithProfile();
    showToast('Ordem e visibilidade das colunas aplicadas!');
  });
  
  // Marcar / Desmarcar todas as colunas
  document.getElementById('btnSelectAllColumns')?.addEventListener('click', () => {
    State.currentProfile.columns.forEach(c => c.visible = true);
    renderColumnsModalList();
  });
  document.getElementById('btnUnselectAllColumns')?.addEventListener('click', () => {
    State.currentProfile.columns.forEach(c => c.visible = false);
    renderColumnsModalList();
  });
  
  // Inverter seleção de colunas
  document.getElementById('btnInvertColumnsSelection')?.addEventListener('click', () => {
    State.currentProfile.columns.forEach(c => c.visible = !c.visible);
    renderColumnsModalList();
  });

  // Restaurar ordem original da planilha
  document.getElementById('btnResetColumnsOrder')?.addEventListener('click', () => {
    if (State.columns.length === 0) return;
    const shiftColName = State.currentProfile?.shiftConfig?.targetColumnName || 'Turno';
    const originalCols = [];
    State.columns.forEach(colName => {
      const existing = State.currentProfile.columns.find(c => c.name === colName);
      originalCols.push({ 
        name: colName, 
        customName: existing ? (existing.customName || '') : '', 
        visible: existing ? existing.visible : true 
      });
      if (colName === State.currentProfile.shiftConfig?.sourceColumn && State.currentProfile.shiftConfig?.enabled) {
        const existingShift = State.currentProfile.columns.find(c => c.name === shiftColName);
        originalCols.push({ 
          name: shiftColName, 
          customName: existingShift ? (existingShift.customName || 'Turno') : 'Turno', 
          visible: existingShift ? existingShift.visible : true 
        });
      }
    });
    State.currentProfile.columns = originalCols;
    renderColumnsModalList();
    showToast('Ordem original das colunas restaurada.');
  });

  // Botão Congelar / Descongelar 1ª Coluna
  let isFreezeCol = false;
  document.getElementById('btnToggleFreezeCol')?.addEventListener('click', (e) => {
    isFreezeCol = !isFreezeCol;
    const table = document.querySelector('.data-table');
    const btn = document.getElementById('btnToggleFreezeCol');
    if (isFreezeCol) {
      table?.classList.add('freeze-first-col');
      btn.classList.add('btn-primary');
      btn.classList.remove('btn-outline');
      btn.textContent = '📌 1ª Coluna Fixada';
      showToast('Primeira coluna fixada durante a rolagem horizontal.');
    } else {
      table?.classList.remove('freeze-first-col');
      btn.classList.remove('btn-primary');
      btn.classList.add('btn-outline');
      btn.textContent = '📌 Fixar 1ª Coluna';
    }
  });

  // Criar Novo Perfil com a Estrutura da Planilha Aberta
  document.getElementById('btnNewProfileFromData')?.addEventListener('click', () => {
    const defaultName = State.fileName ? `Perfil - ${State.fileName.replace(/\.[^/.]+$/, "")}` : 'Novo Perfil';
    const profileName = prompt('Digite um nome para o novo perfil:', defaultName);
    if (!profileName || profileName.trim() === '') return;

    const newKey = 'perfil_' + Date.now();
    const newProfile = {
      profileName: profileName.trim(),
      description: `Criado para a planilha ${State.fileName || 'personalizada'} com ${State.columns.length} colunas`,
      shiftConfig: JSON.parse(JSON.stringify(State.currentProfile.shiftConfig || DEFAULT_PROFILE.shiftConfig)),
      columns: JSON.parse(JSON.stringify(State.currentProfile.columns)),
      defaultSort: null
    };

    State.profiles[newKey] = newProfile;
    saveProfilesToStorage();
    State.currentProfileKey = newKey;
    State.currentProfile = newProfile;
    updateProfileDropdown();
    showToast(`Novo perfil "${newProfile.profileName}" criado e selecionado!`);
  });

  // Procurar JSON no Explorer / Importar Perfis JSON
  const profileFileInput = document.getElementById('profileFileInput');
  document.getElementById('btnBrowseExplorer')?.addEventListener('click', () => {
    profileFileInput?.click();
  });
  profileFileInput?.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
      importProfileJSON(e.target.files[0]);
      e.target.value = ''; // Permite selecionar o mesmo arquivo novamente
    }
  });
  document.getElementById('btnExportProfile')?.addEventListener('click', exportCurrentProfileJSON);
  
  // Busca Global
  const searchInput = document.getElementById('globalSearchInput');
  searchInput?.addEventListener('input', (e) => {
    State.globalSearch = e.target.value;
    applyFiltersAndSort();
  });
  
  // Limpar Todos os Filtros
  document.getElementById('btnClearAllFilters')?.addEventListener('click', () => {
    State.columnFilters = {};
    State.globalSearch = '';
    if (searchInput) searchInput.value = '';
    applyFiltersAndSort();
    showToast('Todos os filtros foram limpos.');
  });
  
  // Mudança de Tamanho de Página
  document.getElementById('pageSizeSelect')?.addEventListener('change', (e) => {
    State.pageSize = e.target.value;
    State.currentPage = 1;
    renderTable();
    renderPagination();
  });
  
  // Exportações
  document.getElementById('btnExportExcel')?.addEventListener('click', exportDataToExcel);
  document.getElementById('btnExportCSV')?.addEventListener('click', exportDataToCSV);
  
  // Alternar Tema (Dark/Light)
  document.getElementById('btnToggleTheme')?.addEventListener('click', () => {
    const isLight = document.body.getAttribute('data-theme') === 'light';
    if (isLight) {
      document.body.removeAttribute('data-theme');
      localStorage.setItem('leitor_theme', 'dark');
    } else {
      document.body.setAttribute('data-theme', 'light');
      localStorage.setItem('leitor_theme', 'light');
    }
  });
  
  if (localStorage.getItem('leitor_theme') === 'light') {
    document.body.setAttribute('data-theme', 'light');
  }
});
