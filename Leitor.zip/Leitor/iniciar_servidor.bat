@echo off
title Servidor Local - Leitor de Planilhas
echo ========================================================
echo   Iniciando Servidor Web Local para o Leitor...
echo   Acesse no navegador: http://localhost:8080
echo ========================================================
echo.

:: Abre o navegador apos 1 segundo
start "" "http://localhost:8080"

:: Executa o mini-servidor HTTP nativo do Python
python -m http.server 8080
pause
