﻿// Gerado automaticamente pelo LeitorDePlanilhas.exe
window.FOLDER_JSON_FILES = [
  {
    filename: "config_padrao.json",
    data: {
  "profileName": "Turnos de Atendimento (Padrão)",
  "description": "Perfil com turnos A (00h-08h), B (08h-16h) e C (16h-24h) com nomes personalizados de colunas",
  "shiftConfig": {
    "enabled": true,
    "sourceColumn": "Hinicio",
    "targetColumnName": "Turno",
    "rules": [
      {
        "shift": "Turno A",
        "startTime": "00:00",
        "endTime": "08:00",
        "color": "#3b82f6"
      },
      {
        "shift": "Turno B",
        "startTime": "08:00",
        "endTime": "16:00",
        "color": "#10b981"
      },
      {
        "shift": "Turno C",
        "startTime": "16:00",
        "endTime": "24:00",
        "color": "#f59e0b"
      }
    ],
    "defaultShift": "Sem Turno"
  },
  "columns": [
    { "name": "cód.", "customName": "Código do Item", "visible": true },
    { "name": "Produto", "customName": "Descrição do Produto", "visible": true },
    { "name": "Inicio", "customName": "Data Inicial", "visible": true },
    { "name": "Hinicio", "customName": "Hora Inicial", "visible": true },
    { "name": "Turno", "customName": "Turno de Atendimento", "visible": true },
    { "name": "Final", "customName": "Data Final", "visible": true },
    { "name": "Hfim", "customName": "Hora Final", "visible": true }
  ],
  "defaultSort": {
    "column": "cód.",
    "direction": "asc"
  }
}
  },
  {
    filename: "exemplo_turno_fabrica.json",
    data: {
  "profileName": "Turnos de Produção / Fábrica",
  "description": "Perfil com 1º Turno (06h-14h), 2º Turno (14h-22h) e 3º Turno (22h-06h)",
  "shiftConfig": {
    "enabled": true,
    "sourceColumn": "Hinicio",
    "targetColumnName": "Turno",
    "rules": [
      {
        "shift": "1º Turno",
        "startTime": "06:00",
        "endTime": "14:00",
        "color": "#10b981"
      },
      {
        "shift": "2º Turno",
        "startTime": "14:00",
        "endTime": "22:00",
        "color": "#3b82f6"
      },
      {
        "shift": "3º Turno",
        "startTime": "22:00",
        "endTime": "06:00",
        "color": "#8b5cf6"
      }
    ],
    "defaultShift": "Geral"
  },
  "columns": [
    { "name": "cód.", "customName": "Código Item", "visible": true },
    { "name": "Produto", "customName": "Linha de Produção", "visible": true },
    { "name": "Inicio", "customName": "Data Início", "visible": true },
    { "name": "Hinicio", "customName": "Hora Entrada", "visible": true },
    { "name": "Turno", "customName": "Turno de Produção", "visible": true },
    { "name": "Final", "customName": "Data Saída", "visible": true },
    { "name": "Hfim", "customName": "Hora Saída", "visible": true }
  ],
  "defaultSort": {
    "column": "cód.",
    "direction": "asc"
  }
}
  },
];
